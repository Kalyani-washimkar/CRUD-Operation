from django.db import models

# Create your models here.
class AllBooks(models.Model):
    name = models.CharField(max_length=100)
    author = models.CharField(max_length=70)
    quantity = models.IntegerField(max_length=100)


class Details_admin(models.Model):
    username = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    password = models.CharField(max_length=100)