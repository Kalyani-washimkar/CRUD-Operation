from django.contrib import admin
from django.urls import path
from LMS import views

urlpatterns = [
    path('', views.Admin_signup, name='home'),
    path('allbooks/', views.add_show_books, name='showallbooks'),
    path('delete/<int:id>', views.delete_book, name='deletedata'),
    path('<int:id>/', views.update, name='updatedata'),
    path('signin/', views.signin, name='login'),
    path('signout/', views.signout, name = 'signout'),
    path('studentview/', views.student_view, name = 'student_view'),
]
