from django.shortcuts import render, HttpResponseRedirect, redirect, HttpResponse
from .forms import Admin, Add_book
from .models import AllBooks, Details_admin
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages


# Create your views here.
def index(request):
    return render(request, 'index.html')

def Admin_signup(request):
    if request.method == 'POST':
        fm = Admin(request.POST)
        if fm.is_valid():
            fm.save()
            messages.success(request, 'Your account has been successfully created.')
            fm = Admin()
    else:
        fm = Admin()
    return render(request, 'signup.html', {'form':fm})


def signin(request):

    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']

        users = Details_admin.objects.all().filter(email=email, password=password)

        for user in users:
            if user.email==email and user.password==password:
                return redirect('showallbooks')
            else:
                return render(request, 'signup.html')

    return render(request, 'Signin.html')


def signout(request):
    logout(request)
    return redirect('home')


def add_show_books(request):
    if request.method == 'POST':
        fm = Add_book(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            au = fm.cleaned_data['author']
            qt = fm.cleaned_data['quantity']
            bk = AllBooks(name=nm, author=au, quantity=qt)
            bk.save()
            fm = Add_book()
    else:
        fm = Add_book()
    book = AllBooks.objects.all()
    return render(request, 'show_books.html', {'form':fm, 'book':book})

def update(request, id):
    if request.method == 'POST':
        pi = AllBooks.objects.get(pk=id)
        fm = Add_book(request.POST, instance=pi)
        if fm.is_valid():
            fm.save()
    else:
        pi = AllBooks.objects.get(pk=id)
        fm = Add_book(instance=pi)
    return render(request, 'update.html', {'form':fm})

def delete_book(request, id):
    if request.method == 'POST':
        pi = AllBooks.objects.get(pk=id)
        pi.delete()
        return redirect('showallbooks')

def student_view(request):
    book = AllBooks.objects.all()
    return render(request, 'student_view.html', {'book':book})