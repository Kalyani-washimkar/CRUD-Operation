from django import forms
from .models import AllBooks, Details_admin


class Admin(forms.ModelForm):
    class Meta:
        model = Details_admin
        fields = ['username', 'email', 'password']
        widgets = {
            'username':forms.TextInput(attrs={'class':'form-control'}),
            'email':forms.EmailInput(attrs={'class':'form-control'}),
            'password':forms.PasswordInput(attrs={'class':'form-control'}),
        }
    
    def clean_email(self):
        email = self.cleaned_data.get('email')
        try:
            match = Details_admin.objects.get(email=email)
        except Details_admin.DoesNotExist:
            return email

        raise forms.ValidationError('This email id is already exist')

class Add_book(forms.ModelForm):
    class Meta:
        model = AllBooks
        fields = ['name', 'author', 'quantity']
        widgets = {
            'name':forms.TextInput(attrs={'class':'form-control'}),
            'author':forms.TextInput(attrs={'class':'form-control'}),
            'quantity':forms.NumberInput(attrs={'class':'form-control'}),
        }


        